document.addEventListener('DOMContentLoaded', () => {
  fetch('data/articles.json')
    .then(response => response.json())
    .then(articles => {
      const container = document.getElementById('article-list');
      articles.forEach(article => {
        const elem = document.createElement('article');
        elem.innerHTML = `
          <h2><a href="${article.content}">${article.title}</a></h2>
          <p><strong>${article.author}</strong></p>
          <p>${article.excerpt}</p>
        `;
        container.appendChild(elem);
      });
    });
});
